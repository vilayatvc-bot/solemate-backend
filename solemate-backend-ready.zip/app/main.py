from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from typing import Optional
import os
from pymongo import MongoClient
from bson import ObjectId

app = FastAPI(title="Solemate Backend API", version="1.0.0")

MONGODB_URI = os.getenv("MONGODB_URI")
client = MongoClient(MONGODB_URI) if MONGODB_URI else None
db = client[os.getenv("MONGODB_DB", "solemate")] if client else None
products = db.products if db is not None else None
orders = db.orders if db is not None else None

class Product(BaseModel):
    name: str
    price: float = Field(gt=0)
    stock: int = Field(ge=0)
    size: Optional[str] = None
    color: Optional[str] = None
    image_url: Optional[str] = None
    description: Optional[str] = None

class OrderItem(BaseModel):
    product_id: str
    quantity: int = Field(gt=0)

class Order(BaseModel):
    customer_name: str
    phone: str
    address: str
    items: list[OrderItem]

@app.get("/")
def root():
    return {"message": "Solemate Backend is running"}

@app.get("/health")
def health():
    if db is None:
        return {"status": "ok", "mongodb": "not_configured"}
    try:
        client.admin.command("ping")
        return {"status": "ok", "mongodb": "connected"}
    except Exception:
        return {"status": "ok", "mongodb": "error"}

@app.get("/products")
def list_products():
    if products is None:
        raise HTTPException(500, "MONGODB_URI is not configured")
    result=[]
    for p in products.find().sort("_id", -1):
        p["id"]=str(p.pop("_id"))
        result.append(p)
    return result

@app.post("/products")
def create_product(product: Product):
    if products is None:
        raise HTTPException(500, "MONGODB_URI is not configured")
    doc=product.model_dump()
    result=products.insert_one(doc)
    return {"id": str(result.inserted_id), **doc}

@app.get("/products/{product_id}")
def get_product(product_id: str):
    if products is None:
        raise HTTPException(500, "MONGODB_URI is not configured")
    try:
        p=products.find_one({"_id": ObjectId(product_id)})
    except Exception:
        raise HTTPException(400, "Invalid product id")
    if not p:
        raise HTTPException(404, "Product not found")
    p["id"]=str(p.pop("_id"))
    return p

@app.post("/orders")
def create_order(order: Order):
    if orders is None:
        raise HTTPException(500, "MONGODB_URI is not configured")
    doc=order.model_dump()
    doc["status"]="pending"
    result=orders.insert_one(doc)
    return {"id": str(result.inserted_id), "status": "pending"}

@app.get("/orders")
def list_orders():
    if orders is None:
        raise HTTPException(500, "MONGODB_URI is not configured")
    result=[]
    for o in orders.find().sort("_id", -1):
        o["id"]=str(o.pop("_id"))
        result.append(o)
    return result
