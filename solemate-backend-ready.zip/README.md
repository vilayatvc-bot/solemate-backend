# Solemate Backend

FastAPI + MongoDB backend for a socks-selling app.

## Run locally

1. Create a virtual environment.
2. Install dependencies:
   `pip install -r requirements.txt`
3. Copy `.env.example` to `.env`.
4. Put your MongoDB Atlas connection string in `.env`.
5. Start:
   `uvicorn app.main:app --reload`

API:
- `GET /health`
- `GET /products`
- `POST /products`
- `GET /products/{product_id}`
- `POST /orders`
- `GET /orders`

Interactive API docs are available at `/docs`.

Never commit `.env` or any real database credentials.
